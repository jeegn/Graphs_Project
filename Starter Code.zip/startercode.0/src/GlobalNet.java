public class GlobalNet {
    //creates a global network 
    //O : the original graph
    //regions: the regional graphs
    public static Graph run(Graph O, Graph[] regions) {
	//To be implemented
    }
}
    
    
    