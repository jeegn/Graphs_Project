public class RegNet {
    //creates a regional network
    //G: the original graph
    //max: the budget
    public static Graph run(Graph G, int max) {
	//To be implemented
    }
}